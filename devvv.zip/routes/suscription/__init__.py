from .suscription_routes import router as suscription_router

__all__ = ["suscription_router"]
